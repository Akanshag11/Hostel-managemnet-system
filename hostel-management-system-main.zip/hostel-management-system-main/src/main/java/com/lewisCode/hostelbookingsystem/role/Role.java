package com.lewisCode.hostelbookingsystem.role;

public enum Role {
    ADMIN,
    STUDENT;
}
